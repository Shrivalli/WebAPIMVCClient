﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WebapicoreClient.Models;

namespace WebapicoreClient.Controllers
{
    public class employeeController : Controller
    {
        public static string url ="https://localhost:44363/api/empls";
        public async Task<IActionResult> Index()
        {
            List<Empl> EmployeeList = new List<Empl>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://localhost:44363/api/empls")) 
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    EmployeeList = JsonConvert.DeserializeObject<List<Empl>>(apiResponse);
                }
            }
            return View(EmployeeList);
        }

        public ViewResult GetReservation() => View();

        [HttpGet]
        public async Task<IActionResult> GetReservation(int id)
        {
            Empl e = new Empl();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://localhost:44363/api/empls/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    e = JsonConvert.DeserializeObject<Empl>(apiResponse);
                }
            }
            return View(e);
        }

        public async Task<IActionResult> AddReservation()
        {
            return View();
        }

        //  public ViewResult AddReservation() => View();

        [HttpPost]
        public async Task<IActionResult> AddReservation(Empl reservation)
        {
            Empl Emplobj = new Empl();
            using (var httpClient = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(reservation), Encoding.UTF8, "application/json");

                using (var response = await httpClient.PostAsync("https://localhost:44363/api/empls/", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    Emplobj = JsonConvert.DeserializeObject<Empl>(apiResponse);
                }
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> UpdateReservation(int id)
        {
            Empl reservation = new Empl();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://localhost:44363/api/empls/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    reservation = JsonConvert.DeserializeObject<Empl>(apiResponse);
                }
            }
            return View(reservation);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateReservation(Empl reservation)
        {
            Empl receivedReservation = new Empl();
            int id = receivedReservation.Empid;
            using (var httpClient = new HttpClient())
            {
                var content = new MultipartFormDataContent();
                content.Add(new StringContent(reservation.Empid.ToString()), "Empid");
                content.Add(new StringContent(reservation.Name), "Name");
                content.Add(new StringContent(reservation.Gender), "Gender");
                content.Add(new StringContent(reservation.Newcity), "Newcity");
                content.Add(new StringContent(reservation.Deptid.ToString()), "Deptid");

                using (var response = await httpClient.PutAsync("https://localhost:44363/api/empls/", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    ViewBag.Result = "Success";
                    receivedReservation = JsonConvert.DeserializeObject<Empl>(apiResponse);
                }
            }
            return RedirectToAction("index");
        }

    }
}